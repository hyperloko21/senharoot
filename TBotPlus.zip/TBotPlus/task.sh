#!/bin/bash
crontab -l > crontab_new
echo "* * * * * /root/.nvm/versions/node/v16.16.0/bin/node /etc/TerminusBot/WhasupBotJS/src/TWABotPGStatus.js" >> crontab_new
crontab crontab_new
rm crontab_new