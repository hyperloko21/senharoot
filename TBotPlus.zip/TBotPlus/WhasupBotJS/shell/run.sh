#!/bin/bash
dir=$(pwd | sed 's/shell//g')
home=$(echo $HOME)

if [[ ! -f /etc/TerminusBot/WhasupBotJS/cache/auth_info_multi.json ]]
then
cat << FECHA
========================== 
    GERANDO QR-CODE 
==========================
FECHA
    sleep 3
    clear
    $home'/nvm/versions/node/v16.16.0/bin/node' /etc/TerminusBot/WhasupBotJS/index.js
fi

if [[ -f /etc/TerminusBot/WhasupBotJS/cache/auth_info_multi.json ]]
then
    screen -dmS twabot 
    screen -S twabot -p 0 -X stuff  "node /etc/TerminusBot/WhasupBotJS/src/TWBotStart.js\n"
    bash /etc/TerminusBot/task.sh

    clear

cat << FECHA
========================== 
        BOT ONLINE 
==========================
FECHA
 sleep 2
 clear

    bash terminus
fi