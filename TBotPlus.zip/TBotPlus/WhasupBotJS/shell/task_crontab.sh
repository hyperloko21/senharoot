#!/bin/bash
node /etc/TerminusBot/WhasupBotJS/src/TWABotPGStatus.js