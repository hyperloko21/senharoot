const fs = require("fs")
const data = fs.readFileSync(__dirname.replace("src/","")+"/usuarios/pedidos.json", "utf-8")
console.log(data)