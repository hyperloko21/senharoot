const {TWABotLoginLimit, TWABotFirstLoginTime} = require("../src/TWABotData")
module.exports.newOrder = newOrder = ({orderId, chatId, status}) => {
    return  {
    "order_id": orderId,
    "chat_id": chatId,
    "status": status,
    "send" : false,
    "limit" : TWABotLoginLimit(),
    "expire" : TWABotFirstLoginTime()
}
}