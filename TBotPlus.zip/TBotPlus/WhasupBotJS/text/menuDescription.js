const {TWABotFirstLoginTime} = require('../src/TWABotData')
module.exports.description = () => {
    
    return {
        text: `O que este bot pode fazer

✅ /start - Inicia o menu
        
✅ Comprar acesso VPN - Compre seu acesso para  ${TWABotFirstLoginTime()} dias
        
✅ Criar teste Grátis - Você só pode criar 1 teste a cada 24 horas.
        
✅ Suporte ao Cliente - Entre em contato conosco!
        
✅ Download Aplicativo - Baixa nosso Aplicativo da Play Store.
        
✅ Baixar arquivo de conexão
        
📍 SEMPRE REALIZE UM TESTE ANTES DA CONTRATAÇÃO!
QUALQUER DúVIDA FICAREMOS FELIZES EM SANAR.`,
        footer: 'Feito por Renato A. dos Santos',
        buttons:  [
            {buttonId: 'continuar', buttonText: {displayText: 'Continuar'}, type: 1},
            {buttonId: 'sair', buttonText: {displayText: 'Sair'}, type: 1},
          ],
        headerType: 1
    }
}