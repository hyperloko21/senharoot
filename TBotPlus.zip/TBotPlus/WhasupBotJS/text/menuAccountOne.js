const {TWABotFirsLoginPrice, TWABotFirstLoginTime, TWABotLoginLimit} = require('../src/TWABotData')
module.exports.menuAccounOne = () => {
    const buttons = [
        {buttonId: 'comprar', buttonText: {displayText: 'Comprar'}, type: 1},
        {buttonId: 'cancelar', buttonText: {displayText: 'Cancelar'}, type: 1},
      ]

    return { 
text: `📌  DETALHES DA COMPRA 📌

👜 *PRODUTO:* ACESSO VPN

💰 *PREÇO:* ${TWABotFirsLoginPrice()} Reais

📅 *VALIDADE:* ${TWABotFirstLoginTime()} Dias

👤 *USUÁRIOS:* ${TWABotLoginLimit()} Usuário`,
footer: 'Feito por Renato A. dos Santos',
buttons: buttons,
headerType: 1

    }
}