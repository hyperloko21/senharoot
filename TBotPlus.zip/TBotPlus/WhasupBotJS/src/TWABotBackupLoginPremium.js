const fs = require("fs")

class UsersDB {
    
    dbDir = "/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json"
    
    createUserDatabase({newUser}){
        
        fs.stat(this.dbDir, (error, stats) => {
           if(error){
            fs.writeFile(this.dbDir, JSON.stringify([newUser], null, 4), (error, bytes) => {
                if(error){
                    console.log(`Erro ao salvar pedido: ${error}`)
                }
                if(bytes){
                    console.log(`Pedido salvo com sucesso! ${bytes}`)
                }
              });

           }else{
               console.log("===== DB EXIST =====")
               fs.readFile(this.dbDir, {encoding: 'utf-8'}, async (error, data) => {
                const array = JSON.parse(data)
                array.push(newUser)
                fs.writeFile(this.dbDir, JSON.stringify(array, null, 4), (error, bytes) => {
                    if(error){
                        console.log(`Erro ao salvar pedido: ${error}`)
                    }
                    if(bytes){
                        console.log(`Pedido salvo com sucesso! ${bytes}`)
                    }
                  });
              })
               
           }
        })
    }

    searchAndGetUser({chatId, callback}){
        if(fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json")){
            const data = fs.readFileSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json", {encoding: "utf-8"})
            const list_account = JSON.parse(data)["account"]
            const result =  list_account.find(findEl => findEl.chat_id == chatId)
            console.log(result)
            callback(result)
        }
    }
}


module.exports.UsersDB = new UsersDB()