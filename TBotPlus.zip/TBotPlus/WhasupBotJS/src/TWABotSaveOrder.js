const fs = require("fs")
const {newOrder} = require("../text/newOrder")


async function TWABotSaveOrder({orderId, chatId, status}){
    
    var  newOrder = {
    "order_id": orderId, 
    "chat_id":  chatId, 
    "status":   status,
    "status":"pending",
    "send":false
    }
    
    function dbExistResult(error, state){
        if(error == null){
            console.log("===== DB EXIST ====")
            const data = fs.readFileSync("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json", "utf-8")
            const array = JSON.parse(data)["result"]
            array.push(newOrder)
            fs.writeFile("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json", JSON.stringify({"result": array}), (error, bytes) => {
                if(error){
                    console.log(`Erro ao salvar pedido: ${error}`)
                }
                if(bytes){
                    console.log(`Pedido salvo com sucesso! ${bytes}`)
                }
            });
        }else{
            console.log("===== DB NOT EXIST ====")
            fs.writeFile("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json", JSON.stringify({"result": [newOrder]}), (error, bytes) => {
                if(error){
                    console.log(`Erro ao salvar pedido: ${error}`)
                }
                if(bytes){
                    console.log(`Pedido salvo com sucesso! ${bytes}`)
                }
            });
        }
    }
    function dbTestExist(){
        //shellExec(`bash /home/renato/WhasupBotJS/shell/criarteste.sh`, callback)
        fs.stat("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json", dbExistResult)
    
    }

    dbTestExist()
}

module.exports.TWABotSaveOrder = TWABotSaveOrder