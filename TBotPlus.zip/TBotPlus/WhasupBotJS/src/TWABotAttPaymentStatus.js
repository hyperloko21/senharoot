const axios = require('axios').default
const fs = require("fs")
const { exec } = require('child_process');
const {TWABotLoginMPInfo} = require("./TWABotData")
const { MessageType, WAProto, proto, delay, useSingleFileAuthState, DisconnectReason , shouldReconnect } = require('@adiwajshing/baileys')
const path = require("path");
const makeWASocket = require('@adiwajshing/baileys').default
const util = require('util');
const { stdout, stderr } = require('process');
const {UsersDB} = require('./TWABotBackupLoginPremium')

class TWABotCheckUpdate {
  dbOrder = async (callback) => {
    const dbDir = "/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json"
    fs.stat(dbDir, (error, stats) => {
      if(error){
        console.log("==== DB NOT EXIST ====")
      }else{
        var listaPagantes = []  
        fs.readFile(dbDir, {encoding: 'utf-8'}, async (error, data) => {
          const array = JSON.parse(data)["result"]
          const length = array.length
          for( let i = 0; i < length; i++ ){
            if(array[i].status.includes("pending")){
            listaPagantes.push(array[i])
            }
          }
          callback(listaPagantes)
        })
      }
    })
   
  }
  
  
  saveDatabase = async (file, callback) => {
    const dbDir = "/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json"
    fs.stat(dbDir, (error, stats) => {
      if(error === null){
        console.log("====== DB PEDIDOS SAVE ======")
        fs.writeFile(dbDir, JSON.stringify({"result": file}), (error, bytes) => {
          if(error){
              console.log(`Erro ao salvar pedido: ${error}`)
          }
          if(bytes){
              console.log(`Pedido salvo com sucesso! ${bytes}`)
              callback()
          }
        });
      }
    })
  }

  databaseUPdate = async (order_id, chat_id, callback) => {
    var update = {
      "order_id": order_id,
      "chat_id": chat_id,
      "status":"approved",
      "send": true
    }

    const dbDir = "/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json"
    fs.readFile(dbDir, 'utf-8', (error, data) => {
      if(data){
        const file = JSON.parse(data)
        const list_account = file.result
        for(var list in list_account){
          if(list_account[list].order_id === order_id){
            list_account.splice(list, 1)
            list_account.push(update)
          }
        }
        
        console.log(list_account)
        fs.writeFile(dbDir, JSON.stringify({"result": list_account}, null, 4), (error, bytes) => {
          console.log("====== DB PEDIDOS SAVE ======")
          callback()
        });
      }
    })
   

  }



  
}

module.exports.TWABotCheckUpdate = new TWABotCheckUpdate()
