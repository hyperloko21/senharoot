const { exec } = require('child_process');
const { dir } = require('console');
const fs = require('fs');
const { stdout, stderr } = require('process');
const {TWABotSaveLoginPremium} = require("./TWABotSavePremiumLogin")
class TWABotCreateLoginPremium {
    create = (chatId, orderID, callback) => {
        exec(`bash /etc/TerminusBot/WhasupBotJS/shell/criarusuario.sh`, (error, stdout, stderr) => {
            const account = JSON.parse(stdout)
            const buttons = [
                            {buttonId: 'btn_playstore', buttonText: {displayText: 'Download PlayStore'}, type: 1},
                            {buttonId: 'btn_mediafire', buttonText: {displayText: 'Download MediaFire'}, type: 1},
            ]
                    
            const buttonMessage = {
                    text: `
                    *CONTA CRIADA COM SUCESSO!*
                    *Usuário:* ${account["Usuario"]}
                    *Senha:* ${account["Senha"]}
                    *Expira:* ${account["expira"]}
                    *Limite:* ${account["limite"]}
                    *Pedido: ${orderID}*`,
                    footer: 'Obrigado por adquirir nosso produto.',
                    buttons: buttons,
                    headerType: 1
            }

           TWABotSaveLoginPremium.save({
            user_account: account["Usuario"], 
            pass_account: account["Senha"], 
            expire_account: account["expira"], 
            limit_account:account["limite"], 
            order_id: orderID,
            chat_id: chatId, callback: () => callback(buttonMessage)})

            
        })
    }
}

module.exports.TWABotCreateLoginPremium = new TWABotCreateLoginPremium()