const { MessageType, WAProto, proto, delay, useSingleFileAuthState, DisconnectReason , shouldReconnect } = require('@adiwajshing/baileys')
const fs = require("fs")
const {TWABotSendLoginTest} = require('./TWABotSendLoginTest')
module.exports.TWABotSendMessage  = async ({jid, message, sock})  =>{

    await delay(500)
	await sock.sendPresenceUpdate('composing', jid)
	await delay(5000)
    await sock.sendPresenceUpdate('paused', jid)
    
    if(message.includes("/createTest")){
        TWABotSendLoginTest({userId: jid, sock: sock})
    }
    
}

