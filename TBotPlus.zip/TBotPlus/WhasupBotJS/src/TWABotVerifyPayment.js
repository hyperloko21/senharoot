const {TWABotLoginMPInfo} = require("./TWABotData")
const axios = require('axios').default

class MP_Payment {
    status = async ({orderId}) => {
        let payment = ""
        await axios({
            method: 'GET',
            url: `https://api.mercadopago.com/v1/payments/${orderId}`,
            headers:  {
                'content-type': 'application/json',
                'Authorization': `Bearer ${TWABotLoginMPInfo()}`
            
              }
          })
          .then((response) => {
              payment = response.data.status
              
          })
          .catch(function (error) {
              console.log(error);
          });
      
          return payment
    }
}

module.exports.TWABotVerifyPayment = new MP_Payment()