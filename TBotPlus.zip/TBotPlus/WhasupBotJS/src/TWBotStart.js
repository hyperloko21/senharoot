const fs = require("fs")
const makeWASocket = require('@adiwajshing/baileys').default
const { MessageType, WAProto, proto, delay, useSingleFileAuthState, DisconnectReason , shouldReconnect } = require('@adiwajshing/baileys')
const path = require("path");
const {description} = require("../text/menuDescription")
const {menuAccounOne} = require("../text/menuAccountOne")
const {TWABotSaveOrder} = require("./TWABotSaveOrder")
const {TWABotPayment} = require("./TWABotPayment")
const {TWABotSendLoginTest} = require("./TWABotSendLoginTest")
const {TWABotLinkSupport, TWABotLinkPlayStore,TWABotLoginMPInfo, TWABotLinkMediafire} = require("./TWABotData")

const {UsersDB} = require("./TWABotBackupLoginPremium")
const { exec } = require('child_process');
const axios = require('axios').default
async function connectToWhatsApp () {
    //const data = fs.readFileSync(dir, "utf-8")
    const { state, saveState } = useSingleFileAuthState(
        path.resolve("/etc/TerminusBot/WhasupBotJS/cache/auth_info_multi.json")
    );

    const sock = makeWASocket({
        // can provide additional config here
        printQRInTerminal: true,
        auth: state
    })

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update
        if(connection === 'close') {
            const shouldReconnect = lastDisconnect.output !== DisconnectReason.loggedOut
            console.log('connection closed due to '+ lastDisconnect.output)
            // reconnect if not logged out
            if(shouldReconnect) {
              connectToWhatsApp()
            }
        } else if(connection === 'open') {
            console.log('opened connection')
        }
    })
//sock.ws.close()


const welcomeMessage = () => {
      const buttonMessage = description()
      return buttonMessage

}

const buttonAccountOne = () => {
    return menuAccounOne()
}


 

const menu_continue = (client) =>{
    // send a buttons message!
    const buttons = [
        {buttonId: 'comprar_acesso', buttonText: {displayText: 'COMPRAR ACESSO SSH'}, type: 1},
        {buttonId: 'teste_gratis', buttonText: {displayText: 'CRIAR TESTE GRÁTIS'}, type: 1},
        {buttonId: 'suporte_cliente', buttonText: {displayText: 'SUPORTE AO CLIENTE'}, type: 1},
        {buttonId: 'confirmar_pagamento', buttonText: {displayText: 'CONFIRMAR PAGAMENTO'}, type: 1}
    ]

    const buttonMessage = {
        text: "*"+client+"* veja nosso catálogo",
        footer: 'by: Renato A. dos Santos',
        buttons: buttons,
        headerType: 1
    }

    return buttonMessage
}

	


const sendMessageTyping = async (jid, message) =>  {
	await delay(500)
	await sock.sendPresenceUpdate('composing', jid)
	await delay(5000)
    await sock.sendPresenceUpdate('paused', jid)
   const response = await sock.sendMessage(jid, message)
}


sock.ev.on("creds.update", saveState);
    sock.ev.on('messages.upsert', async (message) => {

        console.log(JSON.stringify(message, undefined, 2));
        let userID = message.messages[0].key.remoteJid
        await sock.sendPresenceUpdate('available', userID) 

        if(message.messages[0].message){
            const key = message.messages[0].key
            let messageUpdate  =  message.messages[0].message.conversation;
           
            
            if ( messageUpdate.toLowerCase().includes("oi") || 
            messageUpdate.toLocaleLowerCase().includes("boa tarde") || 
            messageUpdate.toLocaleLowerCase().includes("boa noite") || 
            messageUpdate.toLocaleLowerCase().includes("bom dia") || 
            messageUpdate.toLocaleLowerCase().includes("Opa") ||
            messageUpdate.toLocaleLowerCase().includes("Iai") ||
            messageUpdate.toLocaleLowerCase().includes("Eae") || 
            messageUpdate.toLocaleLowerCase().includes("comprar") ){
                delay(500)
                const key = message.messages[0].key
                await sock.readMessages([key])

                await sendMessageTyping(userID, welcomeMessage())
            }

            
            if(message.messages[0].message.buttonsResponseMessage != null ){
            
                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "continuar"){
                    
                    await sock.readMessages([key])

                    await sendMessageTyping(userID, menu_continue(message.messages[0].pushName))
                }

                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "comprar_acesso"){
                    
                    await sock.readMessages([key])
                    await sendMessageTyping(userID, buttonAccountOne())
                }

                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "comprar"){
                   
                    await sock.readMessages([key])
                    try {
                        const datase_exist = fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json")
                        if(datase_exist){
                            const data = fs.readFileSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json", {encoding: "utf-8"})
                            let ssh_account = JSON.parse(data)["result"]
                            let chatExist = ssh_account.find(findEl => findEl.chat_id == userID)
                            if(!chatExist){
                                sendMessageTyping(userID, {text: "*Só um momento estou gerando o código PIX*"})
                                const response = await  TWABotPayment();
                                if(response != null){
                                    if(response.status == "201"){
                                        let qr_code = response.data.point_of_interaction.transaction_data.qr_code
                                        await sendMessageTyping(userID, {text: "*✅ O código de pagamento foi gerado, toque nele para copiar.*"})
                                        await sendMessageTyping(userID, {text: qr_code})
                                        await sendMessageTyping(userID, {text: "*⏳ Assim que recebermos a confirmação do pagamento enviaremos a sua conta automaticamente. Caso isso não aconteça, volte ao menu principal e clique em confirmar pagamento ou digite: '!confirmar' e enviaremos o seu login.*"})
                                        TWABotSaveOrder({orderId: response.data.id, chatId: userID, status:  response.data.status})
                                        
                                    }else{
                                        await sendMessageTyping(userID, {text: "*Desculpa, não consegui processar o seu pedido.*"})
                                    }
                                }else{
                                    await sendMessageTyping(userID, {text: "*Desculpa, não consegui processar o seu pedido.*"})
                                }
                            }
                        }else{
                            sendMessageTyping(userID, {text: "*Só um momento estou gerando o código PIX*"})
                            const response = await  TWABotPayment();
                            if(response != null){
                                if(response.status == "201"){
                                    let qr_code = response.data.point_of_interaction.transaction_data.qr_code
                                    await sendMessageTyping(userID, {text: "*✅ O código de pagamento foi gerado, toque nele para copiar.*"})
                                    await sendMessageTyping(userID, {text: qr_code})
                                    await sendMessageTyping(userID, {text: "*⏳ Assim que recebermos a confirmação do pagamento enviaremos a sua conta automaticamente. Caso isso não aconteça, volte ao menu principal e clique em confirmar pagamento ou digite: '!confirmar' e enviaremos o seu login.*"})
                                    TWABotSaveOrder({orderId: response.data.id, chatId: userID, status:  response.data.status})
                                    
                                }else{
                                    await sendMessageTyping(userID, {text: "*Desculpa, não consegui processar o seu pedido.*"})
                                }
                            }else{
                                await sendMessageTyping(userID, {text: "*Desculpa, não consegui processar o seu pedido.*"})
                            }
                        }
                       
                    } catch (error) {
                        
                    }
                    
                }

                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "teste_gratis"){
                    
                    await sock.readMessages([key])
                    delay(500)
                    TWABotSendLoginTest({userId: userID, sock: sock})
                }

                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "suporte_cliente"){
                   
                    await sock.readMessages([key])
                    delay(500)
                    const link_support = "Envie uma mensagem pelo link: "+TWABotLinkSupport()
                    sendMessageTyping(userID, {text: link_support})
                   
                }
                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "btn_playstore"){
                   
                    await sock.readMessages([key])
                    delay(500)
                    const link_playstore = "Baixe nosso aplicativo pela Play Store por este link: "+TWABotLinkPlayStore()
                    sendMessageTyping(userID, {text: link_playstore})
                   
                }

                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "btn_mediafire"){
                   
                    await sock.readMessages([key])
                    delay(500)
                    const link_mediafire = "Baixe nosso aplicativo  por este link: "+TWABotLinkMediafire()
                    sendMessageTyping(userID, {text: link_mediafire})
                   
                }
                
                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "confirmar_pagamento"){
                    await sock.readMessages([key])
                  

                        UsersDB.searchAndGetUser({chatId: userID, callback: (account) => {
                           
                                

                            if(account){
                                const buttons = [
                                    {buttonId: 'btn_playstore', buttonText: {displayText: 'Download PlayStore'}, type: 1},
                                    {buttonId: 'btn_mediafire', buttonText: {displayText: 'Download MediaFire'}, type: 1},
                                ]
                               var buttonMessage = {
        text: `
        *CONTA CRIADA COM SUCESSO!*
        *Usuário:* ${account.user_account}
        *Senha:* ${account.pass_account}
        *Expira:* ${account.expire_account}
        *Limite:* ${account.limit_account}
        *Pedido:* ${account.order_id}`,
        footer: 'Obrigado por adquirir nosso produto.',
        buttons: buttons,
        headerType: 1
                                }
            
                                sendMessageTyping(userID, buttonMessage)
                            }else{
                                sendMessageTyping(userID, {text: "*Ainda não confirmamos o seu pagamento*"})
                            }



                        }})
                }



                if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "cancelar"){
                    
                    await sock.sendMessage(userID, { delete: key})
                }
            } // Buttons Respnse
            
            if(message.messages[0].message.conversation === "!confirmar"){
                UsersDB.searchAndGetUser({chatId: userID, callback: (account) => {
                    if(account){
                        const buttons = [
                            {buttonId: 'btn_playstore', buttonText: {displayText: 'Download PlayStore'}, type: 1},
                            {buttonId: 'btn_mediafire', buttonText: {displayText: 'Download MediaFire'}, type: 1},
                        ]
                       var buttonMessage = {
    text: `
    *CONTA CRIADA COM SUCESSO!*
    *Usuário:* ${account.user_account}
    *Senha:* ${account.pass_account}
    *Expira:* ${account.expire_account}
    *Limite:* ${account.limit_account}
    *Pedido:* ${account.order_id}`,
    footer: 'Obrigado por adquirir nosso produto.',
    buttons: buttons,
    headerType: 1
                        }
    
                        sendMessageTyping(userID, buttonMessage)
                    }else{
                        sendMessageTyping(userID, {text: "*Ainda não confirmamos o seu pagamento*"})
                    }
                }})
            }
        
        } // Command oi
      
        updateUserPayment()
        /*getAndSendUserAccount({chatId: userID, callback: (account) => {
            var contador = 0
            if(account){
                const buttons = [
                    {buttonId: 'btn_playstore', buttonText: {displayText: 'Download PlayStore'}, type: 1},
                    {buttonId: 'btn_mediafire', buttonText: {displayText: 'Download MediaFire'}, type: 1},
                ]
               var buttonMessage = {
                    text: `
                    *CONTA CRIADA COM SUCESSO!*
                    *Usuário:* ${account.user_account}
                    *Senha:* ${account.pass_account}
                    *Expira:* ${account.expire_account}
                    *Limite:* ${account.limit_account}
                    *Pedido:* ${account.order_id}`,
                    footer: 'Obrigado por adquirir nosso produto.',
                    buttons: buttons,
                    headerType: 1
                }
                contador++
                sendMessageTyping(userID, buttonMessage)
                console.log("====== CONTADOR#2: "+contador)
            }

        }})*/
    });


}


const saveSSHaccount = ({user_account}) => {
    return new Promise((resolve, rejects) => {
        const fileExists = fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json")
         if(fileExists){
             
             fs.readFile("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json", {encoding: 'utf-8'}, async (error, data) => {
               if(data){

                    if(error) rejects(error)
                    const account_ssh = JSON.parse(data)["account"]
                    for(var i in account_ssh){
                        if(account_ssh[i].order_id == user_account.order_id){
                            account_ssh.splice(i, 1)
                            account_ssh.push(user_account)
                        }
                    }
                    fs.writeFile("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json", JSON.stringify({"account": account_ssh}, null, 4), (error, bytes) => {
                        if(error) rejects(error)
                        console.log("====== SSH ACCOUNT BACKUP SAVE ======")
                        resolve(user_account)

                    })
                }
             
            })
        }
    })
 }
 
 var openFile  = (path) => { 
     return new Promise((resolve, rejects) => {
         try{
             resolve(fs.readFileSync(path, "utf-8"))
         }catch(e){
             rejects(e)
         }
     
     })
 }
 
 var createSSH = ({order_id, chat_id}) => {
     return new Promise((resolve, rejects) => {
         openFile("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json")
         .then((data) => {
             const chat_account = JSON.parse(data)["result"]
             const result = chat_account.find(find => find.send == false)
             if(result){
                 exec(`bash /etc/TerminusBot/WhasupBotJS/shell/criarusuario.sh`, (error, stdout, stderr) => {
                     if(stdout){
                         const ssh_account = JSON.parse(stdout)
                         const payload_ssh = {
                             ssh_account: `${ssh_account.Usuario}`,
                             ssh_password: `${ssh_account.Senha}`,
                             ssh_expire: `${ssh_account.expira}`,
                             ssh_limit: `${ssh_account.limite}`,
                             order_id: `${order_id}`,
                             chat_id: `${chat_id}`
         
                         }
                         resolve(payload_ssh)
                     }else if(error){
                         rejects(error)
                     }
                 })
            }
         })
        
     })
 }
 
 const attPaymentStatus = ({ssh_account}) => {
    return new Promise((resolve, rejects) => {
        const fileExists = fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json")
        contador = 0
        if(fileExists){
        
            fs.readFile("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json", {encoding: 'utf-8'}, async (error, data) => {
                
                const user_chat = JSON.parse(data)["result"]
                    const user_data = user_chat.find(findEl => findEl.order_id == ssh_account.order_id)
                    if(user_data){
                        user_data.send = true
                        user_data.status = "approved"
                    }

                    fs.writeFile("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json", JSON.stringify({"result": user_chat}, null, 4), (error, bytes) => {
                        console.log("====== DB PEDIDOS SAVE ======")
                        console.log("############# DB PEDIDOS ############")
                        console.log("-----> "+data)
                        resolve(ssh_account)
                        return
                    })
                    
            })
        }
    })
 }
 const checkPgStatus = (orderId) => {
    const token = TWABotLoginMPInfo()
     return new Promise(  (resolve, rejects) => {
         let status = ""
                 
         axios({
             method: 'GET',
             url: `https://api.mercadopago.com/v1/payments/${orderId}`,
             headers:  {
                 'content-type': 'application/json',
                 'Authorization': `Bearer ${token}`
             
               }
           })
           .then((response) => {
             resolve(response.data.status)
               
           })
           .catch(function (error) {
               rejects(error)
           })
 
     })
 }
 
 

//{"result":[{"order_id":24286852836,"chat_id":"5521995935415@s.whatsapp.net","status":"pending","send":false}]}

function getAndSendUserAccount({chatId, callback}){
    setInterval(() => {
        const fileExists = fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json")
        if(fileExists){
            fs.readFile("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json", "utf-8", (error, data) => {
               let ssh_account = JSON.parse(data)["result"]
               let chatExist = ssh_account.find(findEl => findEl.chat_id == chatId)
               let checkSend = ssh_account.find(findEl => findEl.send == false)
               if(chatExist && checkSend){
                    UsersDB.searchAndGetUser({chatId: chatId, callback: (account) => {
                        attPaymentStatus({ssh_account: account}).then((ssh_account) => {
                            callback(ssh_account)
                            return
                        })
                        console.log(`======== SEND ACCOUNT TO: ${ssh_account.chat_id} ==========`)
                    }})
                }
            })
        }
    }, 120000)
}

function updateUserPayment(callback){
    setInterval(() => {
        const fileExists = fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json")
        if(fileExists){
            console.log("===== DB PEDIDOS EXIST ====")
            // Abre o arquivo pedidos e verfica o status se foi aprovado
            openFile("/etc/TerminusBot/WhasupBotJS/usuarios/pedidos.json")
            .then((data) => {
          
                if(data){
                    const account_list = JSON.parse(data)["result"]
                    for(var i in  account_list){
                        let account = account_list[i]
                        if( account_list[i].status == "pending" &&  account_list[i].send == false){
                            console.log("======= CONFIRMANDO PAGAMENTO =======")
                            checkPgStatus(account.order_id).then((data) => {
    if(data == "approved" && account.send == false){
        console.log("======== PAYMENT CONFIRMED SUCCESSFULLY ==========")
        const backupExist = fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json")
        if(backupExist){
            console.log("====== BACKUP FILE EXIST ======")
            openFile("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json")
            .then((data) =>{
                console.log("========== PRINT NEW USER ACCOUNT ===========")
                console.log(data)
                const backup_ssh = JSON.parse(data)["account"]
                var orderId = account.order_id
                const result = backup_ssh.find(find => find.order_id == orderId)
                if(result == undefined){
                    console.log("====== BACKUP ACCOUNT NOT EXIST ======")
                    createSSH({order_id: account.order_id, chat_id: account.chat_id})
                    .then((account_ssh) => {
                        console.log("======= SAVE SSH ACCOUNT ======")
                        saveSSHaccount({user_account: account_ssh})
                    })
                }else{
                    console.log("====== BACKUP ACCOUNT EXIST ======")
                    
                }
            })
        }else{
            console.log("====== BACKUP FILE NOT EXIST ======")
            createSSH({order_id: account.order_id, chat_id: account.chat_id})
            .then((user_account) => {
                console.log("======= SAVE SSH ACCOUNT ======")
                const ssh_backup =  {
                    user_account: user_account.ssh_account, 
                    pass_account: user_account.ssh_password, 
                    expire_account: user_account.ssh_expire, 
                    limit_account: user_account.ssh_limit, 
                    order_id: user_account.order_id, 
                    chat_id: user_account.chat_id
               }
               fs.writeFile("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json", JSON.stringify({"account": [ssh_backup]}, null, 4), (error, bytes) => {
                    console.log("============ DATABASE USER CREATED AND SAVED =====================")
                })
            })
        }
  
    }
})
                        }
                    }
                }
            })
        }
    }, 120000)
   
}

(async () => {
    connectToWhatsApp();
})()


