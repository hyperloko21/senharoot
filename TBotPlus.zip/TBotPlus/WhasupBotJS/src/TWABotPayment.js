const axios = require('axios').default;
const { TWABotLoginMPInfo, TWABotFirsLoginPrice } = require('./TWABotData')

 async function TWABotPayment(){
   const token = TWABotLoginMPInfo()
   if(token){
        
        const response = await axios.post('https://api.mercadopago.com/v1/payments', `{
            "transaction_amount":  `+parseFloat(TWABotFirsLoginPrice())+`,
            "description": "Título do produto",
            "payment_method_id": "pix",
            "payer": {
              "email": "test@test.com",
              "first_name": "Test",
              "last_name": "User",
              "identification": {
                  "type": "CPF",
                  "number": "19119119100"
              },
              "address": {
                  "zip_code": "06233200",
                  "street_name": "Av. das Nações Unidas",
                  "street_number": "3003",
                  "neighborhood": "Bonfim",
                  "city": "Osasco",
                  "federal_unit": "SP"
              }
            }
          }`, {
          headers: {
            'content-type': 'application/json',
            'Authorization': `Bearer ${TWABotLoginMPInfo()}`
        
          }
        });
        
      return response;
    }else{
      console.log("|===================== TOKEN VAZIO =====================|")
    }
}


module.exports = {
  TWABotPayment : TWABotPayment
}
