
const fs = require("fs")


class BlockUserTest {

    searchAndGetUser({chatId, callback}){
        let status = ""
        if(fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users_testers.json")){
            const account_ssh = fs.readFileSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users_testers.json", {encoding: "utf-8"})
            const account_list = JSON.parse(account_ssh)
            const user = account_list.find(findEl => findEl.user_chatID == chatId)
            if(user){
                callback(true)
                return
            }else{
                callback(false)
                return
            }
        }else{
            callback(false)
            return
        }
  
    }

    
}

module.exports.TWABotTestBlock = new BlockUserTest()