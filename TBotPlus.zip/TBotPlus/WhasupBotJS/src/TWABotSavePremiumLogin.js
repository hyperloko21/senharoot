const fs = require("fs")
const {TWABotCheckUpdate} = require("./TWABotAttPaymentStatus")
const dbDir = "/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json"



class TWABotSaveLoginPremium{
  
  dbDir = "/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json"
  
  json = ({user_account, pass_account, expire_account, limit_account, order_id, chat_id, }) => {
    return  {
      "user_account": `${user_account}`,
      "pass_account": `${pass_account}`,
      "expire_account": `${expire_account}`,
      "limit_account": `${limit_account}`,
      "order_id": `${order_id}`,
      "chat_id": `${chat_id}`
    }
  }
  save = ({user_account, pass_account, expire_account, limit_account, order_id, chat_id, callback}) => {
   
      
    fs.stat(this.dbDir, (error, stats) => {
      if(error != null){
        console.log("===== DB USERS BACKUP NOT EXIST ====")
        const account = this.json(
          {
            user_account: user_account, 
            pass_account: pass_account, 
            expire_account: expire_account, 
            limit_account: limit_account, 
            order_id: order_id, 
            chat_id: chat_id
          })

        fs.writeFile(this.dbDir, JSON.stringify({"account": [account]}, null, 4), (error, bytes) => {
          callback()
        });
         
      }else if(error == null){
        console.log("==== DB USERS BACKUP EXIST =====")
        fs.readFile(this.dbDir, {encoding: 'utf-8'}, async (error, data) => {
          const account = this.json(
            {
              user_account: user_account, 
              pass_account: pass_account, 
              expire_account: expire_account, 
              limit_account: limit_account, 
              order_id: order_id, 
              chat_id: chat_id
            })

          const account_list = JSON.parse(data)["account"]
          account_list.push(account)
          fs.writeFile(this.dbDir, JSON.stringify({"account": [account]}, null, 4), (error, bytes) => {
            callback()
          });
        })
 
      }
    })
  }

  search = (userID, callback) => {
    console.log("===== SEARCH ACCOUNT =====")
    fs.stat(this.dbDir, (error, stats) => {
      if(error == null){
        fs.readFile(this.dbDir, {encoding: 'utf-8'}, async (error, data) => {
          for(var i in data){
            let account = data[i]
            if(account.chat_id != userID){
              callback(true)
            }
            callback(false)
          }
        })
      }else{
        console.log("===== DB USERS NO EXIST =====")
        callback(true)
      }
    })
  }

  getAccounUser = (userID, callback) =>{
    fs.readFile(this.dbDir, {encoding: 'utf-8'}, async (error, data) => {
      const account_list = JSON.parse(data)["account"]
          for(var i in account_list){
            let account = account_list[i]
            if(account.chat_id === userID){
              callback(account)
            }
            continue
          }
    })
  }
}

module.exports.TWABotSaveLoginPremium =  new TWABotSaveLoginPremium()
