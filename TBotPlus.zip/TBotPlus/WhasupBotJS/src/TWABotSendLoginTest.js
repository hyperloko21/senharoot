const { delay } = require('@adiwajshing/baileys');
const { exec } = require('child_process');
const { dir, Console } = require('console');
const fs = require('fs');
const { stdout, stderr } = require('process');
const {TWABotTestBlock} = require('./TWABotTestBlock')

// Enviar conta de teste
async function TWABotSendLoginTest({userId, sock}){
    const db_test = '/etc/TerminusBot/WhasupBotJS/usuarios/database_users_testers.json'

    const sendMessageTyping = async (jid, message) =>  {

        await delay(500)
        await sock.sendPresenceUpdate('composing', jid)
        await delay(5000)
        await sock.sendPresenceUpdate('paused', jid)
        await sock.sendMessage(jid, message)

    }
    function sendMessageUserAlreadyCreatedTest({jid}){

        sendMessageTyping(jid, {text:"*☒ Você já esgotou sua cota de teste grátis.*"})

    }

    if(fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users_testers.json")){
        console.log("============ DATABASE USERSTESTERS ALREADY EXIST =======================")
        TWABotTestBlock.searchAndGetUser({chatId: userId, callback: (result) => {
            if(result){
                sendMessageUserAlreadyCreatedTest({jid: userId})
                return
            }else{
                exec(`bash /etc/TerminusBot/WhasupBotJS/shell/criarteste.sh`, async (error, stdout, stderr) => {
                    const account = JSON.parse(stdout)
                    const account_test = 
                        {
                            "chat_id": userId,
                            "IP": account.IP,
                            "Usuario": account.Usuario,
                            "Senha": account.Senha,
                            "expira": account.expira,
                            "limite": account.limite,
                        }
                        createJSONdatabase()
                        console.log("============= CREATED USER TEST =================")
                        await sendLoginTest({jid: userId, login: account_test})
                });
            }
           
        }})
    }else{
        
        console.log("============ DATABASE USERSTESTERS NOT EXIST =======================")
        exec(`bash /etc/TerminusBot/WhasupBotJS/shell/criarteste.sh`, (error, stdout, stderr) => {
             const account = JSON.parse(stdout)
             const account_test = 
             {
                 "chat_id": userId,
                 "IP": account.IP,
                 "Usuario": account.Usuario,
                 "Senha": account.Senha,
                 "expira": account.expira,
                 "limite": account.limite,
             }
             createJSONdatabase({db_exist: true})
             console.log("============= CREATED USER TEST =================")
             sendLoginTest({jid: userId, login: account_test})
         });
    }



    function createJSONdatabase(){

        const account_drawer = []
        const new_account = { user_chatID: userId}

       if(! fs.existsSync(db_test)){
        account_drawer.push(new_account)
            fs.writeFile(db_test, JSON.stringify(account_drawer), (error, bytes) => {
                if(error){
                    console.log(`Erro ao salvar pedido: ${error}`)
                }
                if(bytes){
                    console.log(`Pedido salvo com sucesso! ${bytes}`)
                }
            })
       }else {

        const data =  fs.readFileSync(db_test, "utf-8")
        const account_parse = JSON.parse(data)
        account_parse.push(new_account)

        fs.writeFile(db_test, JSON.stringify(account_parse), (error, bytes) => {
            if(error){
                console.log(`Erro ao salvar pedido: ${error}`)
            }
            if(bytes){
                console.log(`Pedido salvo com sucesso! ${bytes}`)
            }
        })

       }
    }


    

    async function sendLoginTest({jid, login}){

        await sendMessageTyping(jid, {text: "*Só um momento estou gerando seu login de teste*"})
        const buttons = [
            {buttonId: 'btn_playstore', buttonText: {displayText: 'Download PlayStore'}, type: 1},
            {buttonId: 'btn_mediafire', buttonText: {displayText: 'Download MediaFire'}, type: 1},
        ]

        const buttonMessage = {
            text: `
*CONTA TESTE CRIADA COM SUCESSO!*
*IP:* ${login["IP"]}
*Usuário:* ${login["Usuario"]}
*Senha:* ${login["Senha"]}
*Expira:* ${login["expira"]}
*Limite:* ${login["limite"]}`,
            footer: 'Hello World',
            buttons: buttons,
            headerType: 1
        }
        await sendMessageTyping(jid, buttonMessage)
    }

 
   
  
}

module.exports.TWABotSendLoginTest = TWABotSendLoginTest
