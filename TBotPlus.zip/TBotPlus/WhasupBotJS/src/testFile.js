const { rejects } = require("assert")
const fs = require("fs")
const path = require("path")
const { resolve } = require("path")
const axios = require('axios').default
const { exec } = require('child_process');
const { Console } = require("console")
const {UsersDB} = require("./TWABotBackupLoginPremium")


// checkPgStatus(account.order_id).then((data) => {
//     if(data == "approved" && account.send == false){
//         console.log("======== PAYMENT CONFIRMED SUCCESSFULLY ==========")
//         const backupExist = fs.existsSync("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json")
//         if(backupExist){
//             console.log("====== BACKUP FILE EXIST ======")
//             openFile("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json")
//             .then((data) =>{
//                 console.log("========== PRINT NEW USER ACCOUNT ===========")
//                 console.log(data)
//                 const backup_ssh = JSON.parse(data)["account"]
//                 var orderId = account.order_id
//                 const result = backup_ssh.find(find => find.order_id == orderId)
//                 if(result == undefined){
//                     console.log("====== BACKUP ACCOUNT NOT EXIST ======")
//                     createSSH({order_id: account.order_id, chat_id: account.chat_id})
//                     .then((account_ssh) => {
//                         console.log("======= SAVE SSH ACCOUNT ======")
//                         saveSSHaccount({user_account: account_ssh})
//                     })
//                 }else{
//                     console.log("====== BACKUP ACCOUNT EXIST ======")
                    
//                 }
//             })
//         }else{
//             console.log("====== BACKUP FILE NOT EXIST ======")
//             createSSH({order_id: account.order_id, chat_id: account.chat_id})
//             .then((user_account) => {
//                 console.log("======= SAVE SSH ACCOUNT ======")
//                 const ssh_backup =  {
//                     user_account: user_account.ssh_account, 
//                     pass_account: user_account.ssh_password, 
//                     expire_account: user_account.ssh_expire, 
//                     limit_account: user_account.ssh_limit, 
//                     order_id: user_account.order_id, 
//                     chat_id: user_account.chat_id
//                }
//                fs.writeFile("/etc/TerminusBot/WhasupBotJS/usuarios/database_users.json", JSON.stringify({"account": [ssh_backup]}, null, 4), (error, bytes) => {
//                     console.log("============ DATABASE USER CREATED AND SAVED =====================")
//                 })
//             })
//         }
  
//     }
// })


