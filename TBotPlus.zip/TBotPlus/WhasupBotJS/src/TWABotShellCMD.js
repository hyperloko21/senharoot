#! /usr/bin/env node

const { exec } = require('child_process');
const path = require("path");
const { util } = require('util')

function shellExec(command, callback){
    exec(command, function(err,stdout,stderr){
        if(err) {
          callback(stderr);
        } else {
          callback(stdout);
       }
   });
    
}

function callback(shellResult){
  return shellResult
}



module.exports.shellExec = shellExec